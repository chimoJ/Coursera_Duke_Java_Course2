import java.util.*;
import edu.duke.*;

public class VigenereBreaker {
   
    public String sliceString(String message, int whichSlice, int totalSlices) {
        //REPLACE WITH YOUR CODE
        String answer = "";
        for (int k=whichSlice; k< message.length();k++) {
            if((k-whichSlice)%totalSlices == 0){
              String c=message.substring(k,k+1);
              answer = answer + c;
            }
        }
        return answer;
    }
    public void sliceStringtest(){
       String message = "abcdefghijklm";
       String answer = sliceString(message, 6,5);
       System.out.println(answer);
    }
    public int[] tryKeyLength(String encrypted, int klength, char mostCommon) {
        int[] key = new int[klength];
        //WRITE YOUR CODE HERE
        return key;
    }

    public void breakVigenere () {
        //WRITE YOUR CODE HERE
    }
    
}
