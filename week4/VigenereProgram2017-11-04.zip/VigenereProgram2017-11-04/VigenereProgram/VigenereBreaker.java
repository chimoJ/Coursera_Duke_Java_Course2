import java.util.*;
import edu.duke.*;
import java.io.*;
public class VigenereBreaker {
    public HashSet<String> readDictionary(FileResource fr){
       //fr = new FileResource();
       HashSet<String> dic = new HashSet<String>();
       for (String line : fr.lines()) {
         // process each line in turn
         String word = line.toLowerCase();
         dic.add(word);
       }
       return dic;
    }
    public int[] countLetters(String message){
        String alph = "abcdefghijklmnopqrstuvwxyz";
        int[] counts = new int[26];
        for(int k=0; k < message.length(); k++){
            int dex = alph.indexOf(Character.toLowerCase(message.charAt(k)));
            if (dex != -1){
                counts[dex] += 1;
            }
        }
        return counts;
    }
    public int maxIndex(int[] vals){
        int maxDex = 0;
        for(int k=0; k < vals.length; k++){
            if (vals[k] > vals[maxDex]){
                maxDex = k;
            }
        }
        return maxDex;
    }
    public char mostCommonCharIn(HashSet<String> dic){
       char mostCommon='\0';
       StringBuilder alph = new StringBuilder("abcdefghijklmnopqrstuvwxyz");
       int [] counts = new int[26];
         for (String i : dic) {
         // process each item in turn
         String word = i.toLowerCase();
         counts = countLetters(word);
       } 
       int maxDex = maxIndex(counts);
       mostCommon = alph.charAt(maxDex);
       return mostCommon;
    }
    public HashMap<String,HashSet<String>>  buildUpLangDic(){
        HashMap<String,HashSet<String>> languages = new HashMap<String,HashSet<String>>();
        DirectoryResource dr = new DirectoryResource();
        for (File f : dr.selectedFiles()) {
          // process each file in turn
          String FileName = f.getName();
          FileResource fr = new FileResource(f.toString());
          HashSet<String> LanDic = readDictionary(fr);
          languages.put(FileName, LanDic);
        }
        return languages;
    }
    public String breakForAllLanguage(String encrypted,HashMap<String,HashSet<String>> language){
      int maxcount = 0;
      HashSet<String> TheCorrectDic =new HashSet<String>();
      char TheCorrectChar='\0';
      String TheCorrectLanguage = "";
      String contents = encrypted.toLowerCase();
      for (String filename : language.keySet()) {
         HashSet<String> dic = language.get(filename);
         char mostCommon = mostCommonCharIn(dic);
         System.out.println("The language is: "+filename);
         String DecryptCode=breakForlanguage(contents,dic,mostCommon);
         int totalcount = countWords(DecryptCode,dic);
         if (totalcount>maxcount){
             maxcount=totalcount;
             TheCorrectLanguage = filename;
             TheCorrectDic = dic;
             TheCorrectChar = mostCommon;
            }
      } 
      System.out.println("The Correct Language is: "+ TheCorrectLanguage);
      System.out.println("The Correct MostCommonChar is: "+ TheCorrectChar);
      String DecryptCode = breakForlanguage(contents,TheCorrectDic,TheCorrectChar);
      return DecryptCode;
    }
    public void breakVigenere(){
      FileResource fr = new FileResource();
      String contents = fr.asString();
      HashMap<String,HashSet<String>> language = buildUpLangDic();
      String DecryptCode =breakForAllLanguage(contents,language);
      System.out.println("The DecryptCode is: "+DecryptCode.substring(0,100));
    }
    //public void testmostCommonCharIn(){
      // FileResource dr = new FileResource();
      // HashSet<String> dic = readDictionary(dr);
      // char mostcommon = mostCommonCharIn(dic);
      // System.out.println(mostcommon);
    //}
    //public void testcountwords(){
      //  FileResource fr = new FileResource();
      //  String contents = fr.asString();
      //  FileResource dr = new FileResource();
      //  HashSet<String> dic = readDictionary(dr);
      //  int count = countWords(contents,dic);
      //  System.out.println(count);
    //}
    public int countWords(String message, HashSet<String> dic){
        String[] words = message.split("\\W");
        int count = 0;
        for(int i=0; i < words.length; i++){
           String w = words[i];
           if(dic.contains(w)){
             count++;
            }
        }
        return count;
    }
    public String breakForlanguage(String encrypted, HashSet<String> dic, char mostCommon){
        int maxcount=0;
        int correctKeylength=0;
        //String contents = encrypted.toLowerCase();
        for(int keylength =1; keylength<=100; keylength ++){
           int[] key = tryKeyLength(encrypted,keylength,mostCommon);
           VigenereCipher vc = new VigenereCipher(key);
           String DecryptCode= vc.decrypt(encrypted);
           int totalcount = countWords(DecryptCode,dic);
           if (totalcount > maxcount){
             maxcount = totalcount;
             correctKeylength = keylength;
            }
        }
        int[] key = tryKeyLength(encrypted,correctKeylength,mostCommon);
        System.out.println("the key length is: " + correctKeylength);
        System.out.println("the valid word is: "+maxcount);
        VigenereCipher vc = new VigenereCipher(key);
        String DecryptCode= vc.decrypt(encrypted);
        return DecryptCode;
    }
    public String sliceString(String message, int whichSlice, int totalSlices) {
        //REPLACE WITH YOUR CODE
        String answer = "";
        for (int k=whichSlice; k< message.length();k++) {
            if((k-whichSlice)%totalSlices == 0){
              String c=message.substring(k,k+1);
              answer = answer + c;
            }
        }
        return answer;
    }
    public int[] tryKeyLength(String encrypted, int klength, char mostCommon) {
        int[] key = new int[klength];
        CaesarCracker cr = new CaesarCracker();
        //WRITE YOUR CODE HERE
        //String [] answerarray = new String[klength];
        for(int k=0; k < klength; k++){
          String slice = sliceString(encrypted,k,klength);
          key[k]=cr.getKey(slice);
        }
        return key;
    }
    //public void testtrykeyLength(){
        //FileResource fr = new FileResource();
        //String contents = fr.asString();
        //int[] key = tryKeyLength(contents,5,'e');
        //System.out.println( Arrays.toString(key));
    //}
    //public void sliceStringtest(){
       //String message = "abcdefghijklm";
       //String answer = sliceString(message, 6,5);
       //System.out.println(answer);
    //}
    //public void breakVigenere () {
        //WRITE YOUR CODE HERE
        //FileResource fr = new FileResource();
        //String contents = fr.asString();
        //FileResource dr = new FileResource();
        //HashSet<String> dic = readDictionary(dr);
       // String DecryptCode = breakForlanguage(contents,dic,'e');
        //System.out.println("The DecryptCode is: "+DecryptCode.substring(0,100));
    //}
  }
    
