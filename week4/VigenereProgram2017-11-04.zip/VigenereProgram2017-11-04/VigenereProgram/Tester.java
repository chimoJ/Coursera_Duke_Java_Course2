
/**
 * Write a description of Tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.*;
import edu.duke.*;
public class Tester {
   public void CaesarCipherTester(){
       CaesarCipher cc = new CaesarCipher(3);
       FileResource fr = new FileResource();
       String contents = fr.asString();
       String EncryptCode = cc.encrypt(contents);
       String DecryptCode= cc.decrypt(EncryptCode);
       System.out.println("The EncryptCode is: "+EncryptCode);
       System.out.println("The DecryptCode is: "+DecryptCode);
       System.out.println("The Key is: "+cc.toString());
    }
   public void CaesarCrakerTester(){
       CaesarCracker cr = new CaesarCracker('a');
       FileResource fr = new FileResource();
       String contents = fr.asString();
       String DecryptCode = cr.decrypt(contents);
       System.out.println("The DecryptCode is: "+DecryptCode);
    }
   public void VigenereCipherTester(){
       int[] intkey = {17, 14, 12, 4};
       VigenereCipher vc = new VigenereCipher(intkey);
       FileResource fr = new FileResource();
       String contents = fr.asString();
       String EncryptCode = vc.encrypt(contents);
       String DecryptCode= vc.decrypt(EncryptCode);
       System.out.println("The EncryptCode is: "+EncryptCode);
       System.out.println("The DecryptCode is: "+DecryptCode);
    }
}
