import java.util.*;
import edu.duke.*;

public class VigenereBreaker {
   
    public String sliceString(String message, int whichSlice, int totalSlices) {
        //REPLACE WITH YOUR CODE
        String answer = "";
        for (int k=whichSlice; k< message.length();k++) {
            if((k-whichSlice)%totalSlices == 0){
              String c=message.substring(k,k+1);
              answer = answer + c;
            }
        }
        return answer;
    }
    public void sliceStringtest(){
       String message = "abcdefghijklm";
       String answer = sliceString(message, 6,5);
       System.out.println(answer);
    }
    public int[] tryKeyLength(String encrypted, int klength, char mostCommon) {
        int[] key = new int[klength];
        CaesarCracker cr = new CaesarCracker();
        //WRITE YOUR CODE HERE
        //String [] answerarray = new String[klength];
        for(int k=0; k < klength; k++){
          String slice = sliceString(encrypted,k,klength);
          key[k]=cr.getKey(slice);
        }
        return key;
    }
    public void testtrykeyLength(){
        FileResource fr = new FileResource();
        String contents = fr.asString();
        int[] key = tryKeyLength(contents,5,'e');
        System.out.println( Arrays.toString(key));
    }
    public void breakVigenere () {
        //WRITE YOUR CODE HERE
        FileResource fr = new FileResource();
        String contents = fr.asString();
        int[] key = tryKeyLength(contents,5,'e');
        VigenereCipher vc = new VigenereCipher(key);
        //String EncryptCode = vc.encrypt(contents);
        String DecryptCode= vc.decrypt(contents);
        //System.out.println("The EncryptCode is: "+EncryptCode);
        System.out.println("The DecryptCode is: "+DecryptCode.substring(0,100));
    }
  }
    
