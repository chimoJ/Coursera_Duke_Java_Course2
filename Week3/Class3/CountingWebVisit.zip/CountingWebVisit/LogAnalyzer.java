
/**
 * Write a description of class LogAnalyzer here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.util.*;
import edu.duke.*;

public class LogAnalyzer
{
     private ArrayList<LogEntry> records;
     public LogAnalyzer() {
         // complete constructor
         records = new ArrayList<LogEntry>();
     }
     public void readFile(String filename) {
         // complete method
         FileResource fr = new FileResource();
         for (String line: fr.lines()){
            LogEntry le = WebLogParser.parseEntry(line);
            records.add(le);
            }
     }
     public int countUniqueIPs(){
         ArrayList<String> uniqueIps = new ArrayList<String>();
         for (LogEntry le : records) {
            String ipAddr = le.getIpAddress();
            if (!uniqueIps.contains(ipAddr)) {
               uniqueIps.add(ipAddr);
             }
        }
        return uniqueIps.size();
        }
     public void printAllHigherThanNum(int num){
        for (LogEntry le : records){
           int status = le.getStatusCode();
           if (status > num){
            System.out.println("LogEntry whose status code is larger than "+num+" is "+ le);
            }
        }
        }
     public ArrayList<String> uniqueIPVisitOneDay(String SomeDay){
        ArrayList<String> DateRecord = new ArrayList<String>();
        for (LogEntry le : records) {
            Date date = le.getAccessTime();
            String dateStr= date.toString().substring(4,10);
            String ipAddr = le.getIpAddress();
            //System.out.println(dateStr);
            if (dateStr.equals(SomeDay)){
              if (!DateRecord.contains(ipAddr)) {
                DateRecord.add(ipAddr);
               }
            }
        }
        if (DateRecord.size()==0){System.out.println("there is no IP visited at "+SomeDay);}
        else{System.out.println("there is "+DateRecord.size()+" IP visited at "+SomeDay);}
        return DateRecord;
        }
     public int countUniqueIPsInRange(int low, int high){
        ArrayList<String> StatusRecord = new ArrayList<String>();
         for (LogEntry le : records){
           int status = le.getStatusCode();
           String ipAddr = le.getIpAddress();
           if (status >= low && status <= high){
            if (!StatusRecord.contains(ipAddr)) {
                StatusRecord.add(ipAddr);
                //System.out.println(ipAddr);
               }
            }
        }
        if (StatusRecord.size()==0){System.out.println("there is no IP's status code between "+low+" and "+high);}
        else{System.out.println("there is "+StatusRecord.size()+" unique IPs' status code between "+low+" and "+high);}
        return StatusRecord.size();
        }
     public HashMap<String,Integer>countVisitPerIP(){
        HashMap<String,Integer>counts = new HashMap<String,Integer>();
        for (LogEntry le:records){
          String ip =  le.getIpAddress();
          if(!counts.containsKey(ip)){
             counts.put(ip,1);
            }
          else{
            counts.put(ip,counts.get(ip)+1);
            }
        }
        return counts;
        }
     public int mostNumberVisitByIP(HashMap<String,Integer> counts){
        int maximum =0;
        //counts=countVisitPerIP();
        for (String ip: counts.keySet()){
            if (counts.get(ip)>maximum){
              maximum = counts.get(ip);
            }
        }
        return maximum;
        }
     public ArrayList<String> IPsMostVisits(HashMap<String,Integer> counts){
        ArrayList<String> list = new ArrayList<String>();
        //counts=countVisitPerIP();
        int maximum = mostNumberVisitByIP(counts);
        for (String ip: counts.keySet()){
            if(counts.get(ip)==maximum){
              list.add(ip);
            }
        }
        return list;
        }
     public HashMap<String,ArrayList<String>> IPsForDays(){
        HashMap<String,ArrayList<String>> dates = new HashMap<String,ArrayList<String>>();
        for (LogEntry le : records) {
            ArrayList<String> arraylist = new ArrayList<String>();
            Date date = le.getAccessTime();
            String dateStr= date.toString().substring(4,10);
            String ipAddr = le.getIpAddress();
            if(!dates.containsKey(dateStr)){
             arraylist.add(ipAddr);
             dates.put(dateStr,arraylist);
            }
          else{
            arraylist=dates.get(dateStr);
            arraylist.add(ipAddr);
            dates.put(dateStr,arraylist);
            }
        }
        return dates;
        }
     public String DayWithMostIPsVist(HashMap<String,ArrayList<String>> records){
        records = IPsForDays();
        String dateMost="";
        int maximum=0;
        for (String date: records.keySet()){
            if (records.get(date).size()>maximum){
              dateMost=date;
            }
        }
        return dateMost;
        }
     public ArrayList<String> IPsWithMostVisitsOnDay(HashMap<String,ArrayList<String>> records, String someday){
        ArrayList<String> preRecord = new ArrayList<String>();
        ArrayList<String> DateRecord= new ArrayList<String>();
        HashMap<String,Integer>counts = new HashMap<String,Integer>();
        records = IPsForDays();
        //someday = DayWithMostIPsVist(records);
        for (String date: records.keySet()){
            if (date.equals(someday)){
              preRecord = records.get(date);
              for (String ip:preRecord){
                if(!counts.containsKey(ip)){
                   counts.put(ip,1);
                   }
                else{
                   counts.put(ip,counts.get(ip)+1);
                }
              }
              DateRecord = IPsMostVisits(counts);
            }
        }
        return DateRecord;
        }
     public void printAll() {
         for (LogEntry le : records) {
             System.out.println(le);
         }
     }
}
