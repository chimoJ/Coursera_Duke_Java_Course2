
/**
 * Write a description of class Tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.util.*;
import edu.duke.*;
public class Tester
{
    public void testLogEntry() {
        LogEntry le = new LogEntry("1.2.3.4", new Date(), "example request", 200, 500);
        System.out.println(le);
        LogEntry le2 = new LogEntry("1.2.100.4", new Date(), "example request 2", 300, 400);
        System.out.println(le2);
    }
    
    public void testLogAnalyzer() {
        // complete method
        LogAnalyzer la = new LogAnalyzer();
        la.readFile("");
        //la.printAll();
        int count=la.countUniqueIPs();
        //System.out.println("the total unique Ips number is: "+ count);
        //la.printAllHigherThanNum(400);
        //la.uniqueIPVisitOneDay("Mar 24");
        //la.countUniqueIPsInRange(200,299);
        
    }
    public void testCounts(){
        LogAnalyzer la = new LogAnalyzer();
        la.readFile("");
        HashMap<String,Integer> counts=la.countVisitPerIP();
        //for (String ip: counts.keySet()){
            //System.out.println(ip + " visited " + counts.get(ip) + " times");
        //}
        //int maximum = la.mostNumberVisitByIP(counts);
        //System.out.println("the maximum time visit By IP is: "+ maximum);
        //ArrayList list = la.IPsMostVisits(counts);
        //System.out.println("the IP(s) whose has/have maximum visit time are/is "+list);
        HashMap<String,ArrayList<String>> dates = la.IPsForDays();
        //System.out.println(dates);
        //String DateMost = la.DayWithMostIPsVist(dates);
        //System.out.println("the day which has most IPs visits is: "+DateMost);
        //ArrayList<String> DateRecord= la.IPsWithMostVisitsOnDay(dates,DateMost);
        //System.out.println(DateRecord);
        ArrayList<String> DateMostRecord =la.IPsWithMostVisitsOnDay(dates,"Sep 30");
        System.out.println(DateMostRecord);
    }
}